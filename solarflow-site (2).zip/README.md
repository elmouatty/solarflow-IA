
# Solarflow IA

Sitio web oficial de Solarflow IA, una agencia que combina inteligencia artificial y bienestar emocional para ayudar a las personas a organizar su vida, fluir con más claridad y automatizar tareas personales.

Este sitio está construido como una página estática (HTML/CSS) y está desplegado gratuitamente en Render.

## ¿Qué incluye?

- Página de presentación
- Descripción de servicios
- Enlace a redes sociales
- Diseño adaptable y accesible

---

Desarrollado por Solarflow IA 🌞🤖
